library(testthat)
library(vdmR)
test_package("vdmR")
